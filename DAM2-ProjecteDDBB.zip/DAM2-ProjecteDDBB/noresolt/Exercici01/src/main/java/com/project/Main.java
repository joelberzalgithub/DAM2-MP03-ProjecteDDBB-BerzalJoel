package com.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    private static String URL = "jdbc:mysql://localhost:3308/entertainment_hub?useSSL=false&allowPublicKeyRetrieval=true";
    private static String USER = "root";
    private static String PASSWORD = "pwd";

    private static List<Person> people = new ArrayList<>();
    private static List<Customer> customers = new ArrayList<>();
    private static List<Employee> employees = new ArrayList<>();
    private static List<Videoclub> videoclubs = new ArrayList<>();

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            conn.setAutoCommit(false);

            // Create tables
            createTables(conn);

            // Add people
            addPerson(conn, "John Doe", "john@example.com", "12345678A", 30, "1994-05-15", 123456789);
            addPerson(conn, "Jane Smith", "jane@example.com", "87654321B", 25, "1999-11-20", 987654321);
            addPerson(conn, "Michael Johnson", "michael@example.com", "56789012C", 40, "1984-07-10", 456789012);
            addPerson(conn, "Emily Brown", "emily@example.com", "34567890D", 35, "1989-03-25", 234567890);
            addPerson(conn, "David Lee", "david@example.com", "90123456E", 28, "1996-09-05", 345678901);
            addPerson(conn, "Sarah Garcia", "sarah@example.com", "23456789F", 33, "1991-12-30", 567890123);
            addPerson(conn, "Alex Martinez", "alex@example.com", "78901234G", 31, "1993-02-18", 678901234);
            addPerson(conn, "Jessica Taylor", "jessica@example.com", "45678901H", 29, "1995-08-08", 789012345);
            addPerson(conn, "Daniel Lopez", "daniel@example.com", "89012345I", 36, "1988-06-12", 890123456);

            // Add customers
            addCustomer(conn, 1, "base", "Action", "2023-04-15", "2023-10-15");
            addCustomer(conn, 2, "premium", "Drama", "2022-09-20", "2023-09-20");
            addCustomer(conn, 3, "base", "Thriller", "2024-01-10", "2024-07-10");

            // Add employees
            addEmployee(conn, 4, "2023-05-10", "Software Engineer", 60000.00, 40, 20);
            addEmployee(conn, 5, "2022-09-15", "Marketing Manager", 70000.00, 45, 25);
            addEmployee(conn, 6, "2024-01-20", "Human Resources Assistant", 45000.00, 35, 15);

            // Add videoclubs
            addVideoclub(conn, 7, "CineMania", "info@cinemania.com", 987654321, 10.00, 23.00);
            addVideoclub(conn, 8, "Flicks & Chill", "contact@flicksandchill.com", 123456789, 12.00, 22.00);
            addVideoclub(conn, 9, "Silver Screens", "silver.screens@email.com", 555666777, 11.00, 21.30);
            
            // List people
            listPeople(conn);

            // List customers
            listCustomers(conn);

            // List employees
            listEmployees(conn);

            // List videoclubs
            listVideoclubs(conn);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTables(Connection conn) throws SQLException{
        
    }

    public static void addPerson(Connection conn, String name, String email, String dni, int age, String birthdate, int phoneNumber) throws SQLException {
        
    }

    public static void addCustomer(Connection conn, int personId, String type, String genrePreferences, String startingDate, String expirationDate) throws SQLException {
        
    }

    public static void addEmployee(Connection conn, int personId, String hiringDate, String occupation, double salary, int schedule, int availableHolidays) throws SQLException {
        
    }

    public static void addVideoclub(Connection conn, int ownerId, String name, String email, int phoneNumber, double openingTime, double closingTime) throws SQLException {
        
    }

    public static int getPersonIdByName(Connection conn, String name) throws SQLException {
        return -1;
    }

    public static int getCustomerIdByName(Connection conn, String name) throws SQLException {
        return -1;
    }

    public static int getEmployeeIdByName(Connection conn, String name) throws SQLException {
        return -1;
    }

    public static int getVideoclubIdByName(Connection conn, String name) throws SQLException {
        return -1;
    }

    public static void listPeople(Connection conn) throws SQLException {
        
    }

    public static void listCustomers(Connection conn) throws SQLException {
        
    }

    public static void listEmployees(Connection conn) throws SQLException {
        
    }

    public static void listVideoclubs(Connection conn) throws SQLException {
        
    }
}
